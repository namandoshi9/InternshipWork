from django.contrib import admin
from .models import *


@admin.register(UserDetailsTab)
class UserDetailsAdmin(admin.ModelAdmin):
    list_display = [field.name for field in UserDetailsTab._meta.fields]


@admin.register(CmsPage)
class CmsPageAdmin(admin.ModelAdmin):
    list_display = [field.name for field in CmsPage._meta.fields]


@admin.register(Transportation)
class TransportationAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Transportation._meta.fields]


@admin.register(TripDetail)
class TripDetailAdmin(admin.ModelAdmin):
    list_display = [field.name for field in TripDetail._meta.fields]



@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Trip._meta.fields]



@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Cart._meta.fields]



@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Booking._meta.fields]




@admin.register(Members)
class MembersAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Members._meta.fields]




