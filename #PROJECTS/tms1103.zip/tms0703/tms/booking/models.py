from django.db import models
from django.contrib.auth.models import User

class UserDetailsTab(models.Model):
    user_id = models.AutoField(primary_key=True)
    fname = models.CharField(max_length=255, null=True)
    lname = models.CharField(max_length=255, null=True)
    username = models.CharField(max_length=55, null=True)
    phone = models.CharField(max_length=20, null=True)
    email = models.EmailField(max_length=255, null=True)
    dob = models.DateField(null=True)
    address = models.CharField(max_length=255, null=True)
    userrole = models.CharField(max_length=10, null=True)
    idprooftype = models.CharField(max_length=20, null=True)
    idproofnumber = models.CharField(max_length=20, null=True)
    password = models.CharField(max_length=45, null=True)

class CmsPage(models.Model):
    cms_page_id = models.AutoField(primary_key=True)
    page_title = models.CharField(max_length=45)
    description = models.CharField(max_length=255)

    def __str__(self):
        return self.page_title

class Transportation(models.Model):
    transportation_id = models.AutoField(primary_key=True)
    transportation_type = models.CharField(max_length=10)
    transportation_details = models.CharField(max_length=255)

class TripDetail(models.Model):
    trip_detail_id = models.AutoField(primary_key=True)
    start_date = models.DateTimeField(null=True)
    end_date = models.DateTimeField(null=True)
    cost = models.FloatField(null=True)
    transportation_cost = models.FloatField(null=True)
    tax = models.FloatField(null=True)
    transportation = models.ForeignKey(Transportation, on_delete=models.CASCADE)

class Trip(models.Model):
    trip_id = models.AutoField(primary_key=True)
    start_place = models.CharField(max_length=45)
    end_place = models.CharField(max_length=45)
    no_of_day = models.IntegerField(null=True)
    category = models.CharField(max_length=45)
    city = models.CharField(max_length=45)
    cms_page = models.ForeignKey(CmsPage, on_delete=models.CASCADE)
    transportation = models.ForeignKey(Transportation, on_delete=models.CASCADE)
    trip_detail = models.ForeignKey(TripDetail, on_delete=models.CASCADE)

    

class Cart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    created_te = models.DateTimeField(auto_now_add=True)
    updated_te = models.DateTimeField(auto_now=True)
    trip_start = models.DateTimeField(null=True)
    trip_end = models.DateTimeField(null=True)
    pickup_point = models.CharField(max_length=45)
    drop_point = models.CharField(max_length=45)
    no_of_day = models.IntegerField(null=True)
    base_cost = models.FloatField(null=True)
    transportation_cost = models.FloatField(null=True)
    tax = models.FloatField(null=True)
    total_amount = models.FloatField(null=True)
    user = models.ForeignKey(UserDetailsTab, on_delete=models.CASCADE)
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE)
    transportation = models.ForeignKey(Transportation, on_delete=models.CASCADE)

class Booking(models.Model):
    booking_id = models.AutoField(primary_key=True)
    created_te = models.DateTimeField(auto_now_add=True)
    updated_te = models.DateTimeField(auto_now=True)
    trip_start = models.DateTimeField(null=True)
    trip_end = models.DateTimeField(null=True)
    pickup_point = models.CharField(max_length=45)
    drop_point = models.CharField(max_length=45)
    no_of_day = models.IntegerField(null=True)
    base_cost = models.FloatField(null=True)
    transportation_cost = models.FloatField(null=True)
    tax = models.FloatField(null=True)
    total_amount = models.FloatField(null=True)
    payment_method = models.CharField(max_length=10)
    payment_date = models.DateTimeField(null=True)
    booking_status = models.CharField(max_length=10)
    refund_amount = models.FloatField(null=True)
    refund_date = models.DateTimeField(null=True)
    user = models.ForeignKey(UserDetailsTab, on_delete=models.CASCADE)
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE)
    transportation = models.ForeignKey(Transportation, on_delete=models.CASCADE)

class Members(models.Model):
    member_id = models.AutoField(primary_key=True)
    m_name = models.CharField(max_length=55)
    phone = models.CharField(max_length=20, null=True)
    email = models.EmailField(max_length=255, null=True)
    dob = models.DateField(null=True)
    address = models.CharField(max_length=255, null=True)
    idprooftype = models.CharField(max_length=20, null=True)
    idproofnumber = models.CharField(max_length=20, null=True)
    user = models.ForeignKey(UserDetailsTab, on_delete=models.CASCADE)
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE)
    transportation = models.ForeignKey(Transportation, on_delete=models.CASCADE)
